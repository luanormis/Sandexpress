# ✅ SandExpress — Projeto Pronto para Deploy

**Revisado em:** Abril 2026  
**Correções aplicadas:** 6 problemas críticos resolvidos

---

## 🔴 O que foi corrigido

| # | Arquivo | Problema | Correção |
|---|---------|----------|----------|
| 1 | `next.config.ts` | Faltava `output: "standalone"` — Docker quebrava | Adicionado |
| 2 | `package.json` | `lucide-react: ^1.7.0` — versão inexistente no npm | Corrigido para `^0.488.0` |
| 3 | `package.json` | `next: 16.2.2` — versão inexistente | Corrigido para `15.3.1` |
| 4 | `infra/cloudbuild/production.yaml` | `SESSION_SECRET` não era passado — todos os logins quebravam | Adicionado `SESSION_SECRET` |
| 5 | `infra/cloudbuild/production.yaml` | Região `us-central1` (EUA) para público BR | Alterado para `southamerica-east1` |
| 6 | `.env.example` | Arquivo inexistente — sem guia de variáveis | Criado com todas as vars documentadas |

---

## 🚀 Deploy no Vercel (recomendado)

### 1. Banco de dados — execute no Supabase SQL Editor em ordem:
```
infra/supabase-schema.sql       ← schema principal
infra/migration-ajustes.sql     ← colunas adicionais + tabelas OTP/rate-limit
infra/seed-data.sql             ← dados iniciais (opcional)
infra/seed-products.sql         ← produtos de exemplo (opcional)
```

### 2. Variáveis de ambiente no Vercel
```
NEXT_PUBLIC_SUPABASE_URL        → Supabase Dashboard > Settings > API
NEXT_PUBLIC_SUPABASE_ANON_KEY   → Supabase Dashboard > Settings > API
SUPABASE_SERVICE_ROLE_KEY       → Supabase Dashboard > Settings > API
SESSION_SECRET                  → gere com: openssl rand -hex 32
ADMIN_PASSWORD                  → senha forte à sua escolha
NEXT_PUBLIC_APP_URL             → https://seu-projeto.vercel.app
NEXT_PUBLIC_ENV                 → production
```

### 3. Instalar e build local (teste antes do deploy)
```bash
npm install
npm run build
npm run start
```

### 4. Push e deploy
```bash
git add .
git commit -m "deploy: correcoes producao"
git push origin main
```
O Vercel faz deploy automaticamente ao push no `main`.

---

## 🐳 Deploy com Docker / Google Cloud Run

```bash
# Build
docker build \
  --build-arg NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co \
  --build-arg NEXT_PUBLIC_SUPABASE_ANON_KEY=xxx \
  --build-arg NEXT_PUBLIC_APP_URL=https://seu-dominio.com \
  -t sandexpress .

# Run local
docker run -p 3000:3000 \
  -e NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co \
  -e NEXT_PUBLIC_SUPABASE_ANON_KEY=xxx \
  -e SUPABASE_SERVICE_ROLE_KEY=xxx \
  -e SESSION_SECRET=seu-secret-aqui \
  -e ADMIN_PASSWORD=sua-senha-admin \
  sandexpress
```

Para Cloud Run, preencha as substitutions em `infra/cloudbuild/production.yaml` e execute:
```bash
gcloud builds submit --config infra/cloudbuild/production.yaml
```

---

## 🔐 Credenciais padrão (troque em produção!)

| Acesso | URL | Credencial |
|--------|-----|------------|
| Admin | `/admin/admin` (ou `/`) | Senha via `ADMIN_PASSWORD` |
| Vendor | `/vendor/login` | CPF/CNPJ + senha (reset obrigatório no 1º acesso) |
| Cliente | `/u/[umbrella_id]` | Telefone + OTP |

---

## ✅ Health Check

Após o deploy, verifique:
```
GET https://seu-dominio/api/health
```
Resposta esperada: `{"status":"ok","database":"connected"}`

---

## 📱 OTP WhatsApp (opcional)

Por padrão o OTP roda em modo `dev` (código retornado na resposta da API).  
Para ativar envio real, configure **uma** das opções no `.env`:

**Meta WhatsApp Cloud API:**
```
WHATSAPP_TOKEN=seu-token
WHATSAPP_PHONE_ID=seu-phone-id
CUSTOMER_OTP_MODE=required
```

**Twilio:**
```
TWILIO_SID=xxx
TWILIO_TOKEN=xxx
TWILIO_FROM=+55119999999
CUSTOMER_OTP_MODE=required
```
